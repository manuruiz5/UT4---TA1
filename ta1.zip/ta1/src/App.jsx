import Card from './components/Card/index.jsx';  // Asegúrate de que la ruta sea correcta

const App = () => {
  return (
    <div>
      <Card 
        title="Proyecto A" 
        description="Parte 1"
        assignedTo="Nombre Apellido"
        startDate="01/09/2024"
        endDate="15/09/2024" 
      />
      <Card 
        title="Proyecto B" 
        description="Parte 2"
        assignedTo="Nombre Apellido"
        startDate="05/09/2024"
        endDate="20/09/2024" 
      />
      <Card 
        title="Proyecto C" 
        description="Parte 3"
        assignedTo="Nombre Apellido"
        startDate="10/09/2024"
        endDate="25/09/2024" 
      />
    </div>
  );
};

export default App;
